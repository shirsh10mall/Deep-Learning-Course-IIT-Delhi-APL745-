import numpy as np

class Softmax:
  # A standard fully-connected layer with softmax activation.

  def __init__(self, input_len, output_len):
    # After randomly intializing the weights, divide by input_len to reduce the variance
    self.weights = 
    self.biases = 

  def forward(self, input):
    '''
    Performs a forward pass of the softmax layer using the given input.
    Returns a 1d numpy array containing the respective probability values.
    - input can be any array with any dimensions.
    '''
    
    
    
    
    
    
    
    return prob
