import torch
import numpy as np

class PhysicsInformedBarModel:
    """A class used for the definition of Physics Informed Models for one dimensional bars."""

    def __init__(self, x, E, A, L, u0, dist_load):
        # Construct a PhysicsInformedBar model
        # Initialize required variables for the class
        '''
        Params:
            x - spatial value
            E - Young's modulus
            A - cross sectional area
            L - length of the bar
            u0 - displacement at x = 0
            dist_load - distributed load
        '''

        self.x = x
        self.E = E
        self.A = A
        self.L = L
        self.u0 = u0
        self.dist_load = dist_load


    def costFunction(self, x, u_pred):
        # Compute the cost function

        '''
        This function takes input x and model predicted output u_pred to compute loss
        Params:
            x - spatial value
            u_pred - NN predicted displacement value
            differential_equation_loss - calculated PDE residual loss
            boundary_condition_loss - calculated boundary loss
        '''
        self.x = x
        self.u_pred = u_pred
        # collocation points
        # x_collocation = torch.linspace( torch.min(x), torch.max(x) , 1000)
        # PDE residual loss
        du_dx =  self.E*self.A*torch.autograd.grad( outputs=u_pred, inputs=[x], grad_outputs=torch.ones_like(u_pred),create_graph=True, retain_graph=True )
        print( type( du_dx ) )
        f = torch.autograd.grad( outputs=du_dx, inputs=[x], grad_outputs=torch.ones_like(u_pred),create_graph=True, retain_graph=True ) - self.dist_load
        differential_equation_loss = torch.mean( torch.square( f ))
        boundary_condition_loss = torch.mean( torch.square(torch.subtract(x - u_pred)) )
        total_loss = differential_equation_loss + boundary_condition_loss
        return differential_equation_loss, boundary_condition_loss, total_loss
    
    def get_displacements(self, x):
        """Get displacements."""
        '''
        This function is used while inference (you can even use in your training phase if needed.
        It takes x as input and returns model predicted displacement)
        Params:
            x - input spatial value
            u - model predicted displacement
        '''
        self.model.eval()
        u = self.model(x)

        return u
    

    def train(self, epochs, optimizer, lr):
        """Train the model."""
        '''
        This function is used for training the network. While updating the model params use "costFunction" 
        function for calculating loss
        Params:
            epochs - number of epochs
            optimizer - name of the optimizer
            **kwarhs - additional params
        This function doesn't have any return values. Just print the losses during training
        '''

        print("yo")
        self.optimizer = optimizer
        self.lr = lr
        if optimizer == "LBFGS":
            self.optimizer = torch.optim.LBFGS(self.model.parameters(), lr=lr, max_iter=50000, max_eval=None, tolerance_grad=1e-07, tolerance_change=1e-09)
        else:
            self.optimizer = torch.optim.Adam(self.model.parameters())
        
        model = neural_network_model()
        model.train()
        for e in range(1, EPOCHS+1):
            epoch_loss = 0
            epoch_acc = 0
            optimizer.zero_grad()
            u_pred = model(X_batch)

            diff_loss, BC_loss, total_loss = costFunction(x, u_pred)
            total_loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
            print(f'Epoch {e+0:03}: | Total Loss: {loss.item():.5f} | Diff Loss: {diff_loss.item():.5f} | BC Loss: {BC_loss.item():.5f}')

        return model



    
        
        
